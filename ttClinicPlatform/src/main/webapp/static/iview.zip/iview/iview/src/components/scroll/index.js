import Scroll from './scroll.vue';

export default Scroll;
