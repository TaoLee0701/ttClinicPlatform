import Tabs from './tabs.vue';
import Pane from './pane.vue';

Tabs.Pane = Pane;
export default Tabs;