import Tree from './tree.vue';
export default Tree;