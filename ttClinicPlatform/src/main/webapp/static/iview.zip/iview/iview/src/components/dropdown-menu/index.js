import DropdownMenu from '../dropdown/dropdown-menu.vue';

export default DropdownMenu;