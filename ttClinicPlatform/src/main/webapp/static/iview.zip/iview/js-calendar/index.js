
module.exports = {
	Generator: require('./src/jsCalendar'),
	addLabels: require('./src/addLabels')
}
