# Batch Processor
See the `test.js` file for the API and behavior.
