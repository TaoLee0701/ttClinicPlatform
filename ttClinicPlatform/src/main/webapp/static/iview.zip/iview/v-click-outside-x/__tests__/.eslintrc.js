module.exports = {
  rules: {
    'jest/no-hooks': 'off',
  },
};
